package fis.java.topic01.practice01;



public class StudentList {
	private Student[] students =new Student[100];
	private int count;	
	private ISortStrategy sortStrategy;
	
	public void addStudent (Student student){
		
	}
	public Student removeStudent (int code) {
		Student student=new Student();
		return student;
	}
	public void display() {
		
	}
	public void sort() {
		
	}
	public void setSortStrategy(ISortStrategy sortStrategy) {
			
	}
	
}
