package fis.java.topic01.practice01;

public class DecimalValidation implements IValidation{

	@Override
	public boolean validate(String data) {
		// TODO Auto-generated method stub
		return false;
	}

}
