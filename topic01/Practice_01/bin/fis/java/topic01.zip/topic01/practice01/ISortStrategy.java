package fis.java.topic01.practice01;

public interface ISortStrategy {
	public void  sort(Comparable[] data,int count);
}
