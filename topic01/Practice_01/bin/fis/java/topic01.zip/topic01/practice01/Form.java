package fis.java.topic01.practice01;

import java.awt.Component;
import java.util.List;

public class Form {
	public List<Component> components;
	public void addComponent (Component component) {
		
	}
	public boolean validateForm() {
		return true;
	}


}
