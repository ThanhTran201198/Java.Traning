package fis.java.topic01.practice01;

public class StringMaxLengthValidation implements IValidation{
	private int length;
	@Override
	public boolean validate(String data) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
