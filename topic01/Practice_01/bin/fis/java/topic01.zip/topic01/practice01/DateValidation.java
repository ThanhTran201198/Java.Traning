package fis.java.topic01.practice01;

public class DateValidation implements IValidation{
	
	private String format="\\d{2}[-|/]\\d{2}[-|/]\\d{4}";

	@Override
	public boolean validate(String data) {
		// TODO Auto-generated method stub
		return false;
	}

}
