package fis.java.topic01.practice01;

public class InputComponent {
	private IValidation validation;
	private String data;
	
	public void	setData(String data) {
		
	}
	public void display() {
		
	}
	public void setValidation(IValidation validation) {
		
	}
	public void validate() {
		
	}


}
