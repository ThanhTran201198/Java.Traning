package fis.java.topic01.practice01;

public class SelectionSortStrategy implements ISortStrategy{

	@Override
	public void sort(Comparable[] data, int count) {
		// TODO Auto-generated method stub
		
	}

}
