package fis.java.topic01.practice01;

public interface IValidation {
	public boolean validate(String data);


}
