package fis.java.topic01.practice02;

import java.util.ArrayList;

public class Summary {
	private ArrayList<BicycleTicket> bicycleTickets=new ArrayList<BicycleTicket>();
	private ArrayList<MotorbikeTicket> motorbikeTickets=new ArrayList<MotorbikeTicket>();
	public ArrayList<BicycleTicket> getBicycleTickets() {
		return bicycleTickets;
	}
	public ArrayList<MotorbikeTicket> getMotorbikeTickets() {
		return motorbikeTickets;
	}
	public void setBicycleTickets(ArrayList<BicycleTicket> bicycleTickets) {
		this.bicycleTickets = bicycleTickets;
	}
	public void setMotorbikeTickets(ArrayList<MotorbikeTicket> motorbikeTickets) {
		this.motorbikeTickets = motorbikeTickets;
	}
	public int total() {
		return bicycleTickets.size()+motorbikeTickets.size();
	}
	public double totalMoney() {
		return bicycleTickets.size()*500 + motorbikeTickets.size()*1000;
	}
	public double interest() {
		return this.totalMoney()*0.9-this.total()*100;
	}
	
}
