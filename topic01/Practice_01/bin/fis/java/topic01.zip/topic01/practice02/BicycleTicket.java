package fis.java.topic01.practice02;

public class BicycleTicket extends Ticket{

	public BicycleTicket() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BicycleTicket(int ticketNumber) {
		super(ticketNumber);
		// TODO Auto-generated constructor stub
	}
	
}
