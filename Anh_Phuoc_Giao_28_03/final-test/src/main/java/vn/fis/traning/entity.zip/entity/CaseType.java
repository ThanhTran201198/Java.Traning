package vn.fis.traning.entity;

public enum CaseType {
	UNCATEGORIED,INFRATION,MISDEMEANOR,FELONY
}
