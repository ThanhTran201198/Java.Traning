package vn.fis.traning.entity;

public enum TrackAction {
	SUBMITTED,RETREVED,RETURNED;
}
