package vn.fis.traning.entity;

public enum EmploymentStatus {
	ACTIVE,SUSPENDED,VACATION,UNDER_INVESTIGATION,RETIRED
}
