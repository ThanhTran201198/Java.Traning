package vn.fis.traning.entity;

public enum CaseStatus {
	SUBMITTED,UNDER_INVESTIGATION,IN_COURT,COLSE,DISMISSED,COLD
}
